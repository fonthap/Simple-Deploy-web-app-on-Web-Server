(function(window) {
  window["env"] = window["env"] || {};

  // Environment variables
  window["env"]["apmServiceName"] = "angular-16-client";
  window["env"]["apmServerUrl"] = "http://localhost:8200";
  window["env"]["apmEnvironment"] = "dev";
  window["env"]["debug"] = true;
})(this);