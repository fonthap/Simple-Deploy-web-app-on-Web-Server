(function(window) {
  window.env = window.env || {};

  // Environment variables
  window["env"]["apmServiceName"] = "${ELASTIC_APM_SERVICE_NAME }";
  window["env"]["apmServerUrl"] = "${ELASTIC_APM_SERVER_URL}"; 
  window["env"]["apmEnvironment"] = "${ELASTIC_APM_ENVIRONMENT }";
  window["env"]["debug"] = "${DEBUG}";
})(this);